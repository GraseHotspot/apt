<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/internal/api/generate/password' => [[['_route' => 'grase_api_generate_password', '_controller' => 'App\\Controller\\ApiController::apiGeneratePassword'], null, null, null, false, false, null]],
        '/login' => [[['_route' => '_grase_login', '_controller' => 'App\\Controller\\SecurityController::loginAction'], null, null, null, false, false, null]],
        '/login_check' => [[['_route' => '_grase_security_check', '_controller' => 'App\\Controller\\SecurityController::securityCheckAction'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => '_grase_logout', '_controller' => 'App\\Controller\\SecurityController::logoutAction'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'grase_radmin_homepage', '_controller' => 'App\\Controller\\DefaultController::indexAction'], null, null, null, false, false, null]],
        '/user/new' => [[['_route' => 'grase_user_new', '_controller' => 'App\\Controller\\UserController::createUserAction'], null, null, null, false, false, null]],
        '/groups' => [[['_route' => 'grase_groups', '_controller' => 'App\\Controller\\GroupController::displayGroupsAction'], null, null, null, true, false, null]],
        '/settings/advanced' => [[['_route' => 'grase_advanced_settings', '_controller' => 'App\\Controller\\DefaultController::advancedSettingsAction'], null, null, null, false, false, null]],
        '/leases' => [[['_route' => 'grase_dhcp_leases', '_controller' => 'App\\Controller\\DefaultController::dhcpLeasesAction'], null, null, null, false, false, null]],
        '/audit' => [[['_route' => 'grase_auditlog', '_controller' => 'App\\Controller\\DefaultController::auditLogDisplayAction'], null, null, null, false, false, null]],
        '/session' => [[['_route' => 'grase_session', '_controller' => 'App\\Controller\\DefaultController::monitorSessionAction'], null, null, null, false, false, null]],
        '/session/logoutmac' => [[['_route' => 'grase_session_logoutmac', '_controller' => 'App\\Controller\\DefaultControeller::logoutChilliSessionAction'], null, null, null, false, false, null]],
        '/uam' => [[['_route' => 'grase_uam_login', '_controller' => 'App\\Controller\\UamController::uamAction'], null, null, null, false, false, null]],
        '/uam/toslogin' => [[['_route' => 'grase_uam_toslogin', '_controller' => 'App\\Controller\\UamController::tosLoginAction'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/api(?'
                    .'|(?:/(index)(?:\\.([^/]++))?)?(*:42)'
                    .'|/(?'
                        .'|docs(?:\\.([^/]++))?(*:72)'
                        .'|contexts/(.+)(?:\\.([^/]++))?(*:107)'
                        .'|settings(?'
                            .'|(?:\\.([^/]++))?(?'
                                .'|(*:144)'
                            .')'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:182)'
                            .')'
                        .')'
                        .'|groups(?'
                            .'|(?:\\.([^/]++))?(?'
                                .'|(*:219)'
                            .')'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:257)'
                            .')'
                        .')'
                        .'|user(?'
                            .'|_groups(?'
                                .'|(?:\\.([^/]++))?(?'
                                    .'|(*:302)'
                                .')'
                                .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                    .'|(*:340)'
                                .')'
                            .')'
                            .'|s(?'
                                .'|(?:\\.([^/]++))?(?'
                                    .'|(*:372)'
                                .')'
                                .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                    .'|(*:410)'
                                .')'
                            .')'
                        .')'
                    .')'
                .')'
                .'|/js/routing(?:\\.(js|json))?(*:450)'
                .'|/user(?'
                    .'|s(?:/([^/]++))?(*:481)'
                    .'|/([^/]++)/(?'
                        .'|edit(*:506)'
                        .'|delete(*:520)'
                    .')'
                .')'
                .'|/group/([^/]++)/edit(*:550)'
                .'|/settings/advanced/([^/]++)/edit(*:590)'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        42 => [[['_route' => 'api_entrypoint', '_controller' => 'api_platform.action.entrypoint', '_format' => '', '_api_respond' => 'true', 'index' => 'index'], ['index', '_format'], null, null, false, true, null]],
        72 => [[['_route' => 'api_doc', '_controller' => 'api_platform.action.documentation', '_format' => '', '_api_respond' => 'true'], ['_format'], null, null, false, true, null]],
        107 => [[['_route' => 'api_jsonld_context', '_controller' => 'api_platform.jsonld.action.context', '_format' => 'jsonld', '_api_respond' => 'true'], ['shortName', '_format'], null, null, false, true, null]],
        144 => [
            [['_route' => 'api_settings_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Setting', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_settings_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Setting', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        182 => [
            [['_route' => 'api_settings_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Setting', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_settings_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Setting', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_settings_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Setting', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
        ],
        219 => [
            [['_route' => 'api_groups_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\Group', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_groups_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\Group', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        257 => [
            [['_route' => 'api_groups_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\Group', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_groups_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\Group', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_groups_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\Group', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
        ],
        302 => [
            [['_route' => 'api_user_groups_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\UserGroup', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_user_groups_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\UserGroup', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        340 => [
            [['_route' => 'api_user_groups_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\UserGroup', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_user_groups_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\UserGroup', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_user_groups_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\UserGroup', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
        ],
        372 => [
            [['_route' => 'api_users_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\User', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_users_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\User', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        410 => [
            [['_route' => 'api_users_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\User', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_users_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\User', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_users_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Radius\\User', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
        ],
        450 => [[['_route' => 'fos_js_routing_js', '_controller' => 'fos_js_routing.controller::indexAction', '_format' => 'js'], ['_format'], ['GET' => 0], null, false, true, null]],
        481 => [[['_route' => 'grase_users', '_controller' => 'App\\Controller\\UserController::displayUsersAction', 'group' => null], ['group'], null, null, false, true, null]],
        506 => [[['_route' => 'grase_user_edit', '_controller' => 'App\\Controller\\UserController::editUserAction'], ['id'], null, null, false, false, null]],
        520 => [[['_route' => 'grase_user_delete', '_controller' => 'App\\Controller\\UserController::deleteUserAction'], ['user'], ['POST' => 0], null, false, false, null]],
        550 => [[['_route' => 'grase_group_edit', '_controller' => 'App\\Controller\\GroupController::editGroupAction'], ['id'], null, null, false, false, null]],
        590 => [
            [['_route' => 'grase_advanced_settings_edit', '_controller' => 'App\\Controller\\DefaultController::editAdvancedSettingAction'], ['setting'], null, null, false, false, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
