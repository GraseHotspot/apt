<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* auditlog.html.twig */
class __TwigTemplate_26fdf29dfb49949628de674235625005539e7cea0ab6021be8b598c8196bcf8d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_title' => [$this, 'block_page_title'],
            'page_subtitle' => [$this, 'block_page_subtitle'],
            'content' => [$this, 'block_content'],
            'audit_table' => [$this, 'block_audit_table'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html.twig", "auditlog.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_page_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("page.auditlog.header", [], "messages");
    }

    // line 7
    public function block_page_subtitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 8
        echo "
";
    }

    // line 11
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        echo "    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <div class=\"card\">
                    ";
        // line 16
        $this->displayBlock("audit_table", $context, $blocks);
        echo "
                </div>
            </div>
        </div>
    </div>

";
    }

    // line 24
    public function block_audit_table($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 25
        echo "<div class=\"card-header\">
    <h3 class=\"card-title\">";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("page.auditlog.header", [], "messages");
        echo "</h3>
</div>
<div class=\"card-body p-10\">
    <p>";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("page.auditlog.information", [], "messages");
        echo "</p>

    <table id=\"auditLogTable\" class=\"table table-bordered table-hover dataTable\"
           data-paging=\"true\" data-page-length=\"10\" data-searching=\"true\"
           data-ordering=\"true\" data-info=\"true\" data-autowidth=\"true\"
           data-order=\"[[ 1, &quot;desc&quot; ]]\" >
        <thead>
        <tr>
            <th>";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.timestamp", [], "messages");
        echo "</th>
            <th>";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.audit.level", [], "messages");
        echo "</th>
            <th>";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.user", [], "messages");
        echo "</th>
            <th>";
        // line 40
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.ip", [], "messages");
        echo "</th>
            <th>";
        // line 41
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.audit.action", [], "messages");
        echo "</th>
            <th>";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.audit.context", [], "messages");
        echo "</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 47
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["logEntries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 48
            echo "            <tr>
                <td data-order=\"";
            // line 49
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["entry"], "createdAt", [], "any", false, false, false, 49), "U"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, twig_get_attribute($this->env, $this->source, $context["entry"], "createdAt", [], "any", false, false, false, 49), "short", "short"), "html", null, true);
            echo "</td>
                <td>";
            // line 50
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["entry"], "levelName", [], "any", false, false, false, 50), "html", null, true);
            echo "</td>
                <td>";
            // line 51
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["entry"], "username", [], "any", false, false, false, 51), "html", null, true);
            echo "</td>
                <td>";
            // line 52
            echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["entry"], "extra", [], "any", false, true, false, 52), "ip", [], "any", true, true, false, 52)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["entry"], "extra", [], "any", false, true, false, 52), "ip", [], "any", false, false, false, 52), "")) : ("")), "html", null, true);
            echo "</td>
                <td>";
            // line 53
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, $context["entry"], "message", [], "any", false, false, false, 53)), "html", null, true);
            echo "</td>
                <td class=\"json-renderer\" data-json='";
            // line 54
            echo twig_escape_filter($this->env, json_encode(twig_get_attribute($this->env, $this->source, $context["entry"], "context", [], "any", false, false, false, 54)), "html", null, true);
            echo "'></td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "        </tbody>
    </table>
</div>


";
    }

    public function getTemplateName()
    {
        return "auditlog.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  179 => 58,  169 => 54,  165 => 53,  161 => 52,  157 => 51,  153 => 50,  147 => 49,  144 => 48,  139 => 47,  132 => 42,  128 => 41,  124 => 40,  120 => 39,  116 => 38,  112 => 37,  101 => 29,  95 => 26,  92 => 25,  88 => 24,  77 => 16,  71 => 12,  67 => 11,  62 => 8,  58 => 7,  53 => 4,  49 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "auditlog.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/auditlog.html.twig");
    }
}
