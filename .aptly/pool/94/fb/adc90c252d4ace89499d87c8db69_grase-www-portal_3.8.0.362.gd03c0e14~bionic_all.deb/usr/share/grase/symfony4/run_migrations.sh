docker-compose exec webserver /usr/share/grase/symfony4/bin/console doctrine:migrations:migrate
