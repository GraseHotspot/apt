<?php

namespace Grase\RadminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GraseRadminBundle extends Bundle
{
}
