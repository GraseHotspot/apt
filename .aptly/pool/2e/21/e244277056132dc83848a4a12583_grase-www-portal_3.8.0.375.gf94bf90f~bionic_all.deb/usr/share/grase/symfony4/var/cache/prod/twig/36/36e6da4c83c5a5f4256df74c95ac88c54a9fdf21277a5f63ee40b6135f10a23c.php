<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @BazingaJsTranslation/getTranslations.json.twig */
class __TwigTemplate_bfeacce6f608766352300cfff84c527ba84e0eb741935e3b854cc3aade245cad extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "{
";
        // line 2
        if (($context["include_config"] ?? null)) {
            // line 3
            echo "    \"fallback\": \"";
            echo twig_escape_filter($this->env, ($context["fallback"] ?? null), "html", null, true);
            echo "\",
    \"defaultDomain\": \"";
            // line 4
            echo twig_escape_filter($this->env, ($context["defaultDomain"] ?? null), "html", null, true);
            echo "\",
";
        }
        // line 6
        echo "    \"translations\": ";
        echo json_encode(($context["translations"] ?? null));
        echo "
}
";
    }

    public function getTemplateName()
    {
        return "@BazingaJsTranslation/getTranslations.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 6,  47 => 4,  42 => 3,  40 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@BazingaJsTranslation/getTranslations.json.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/vendor/willdurand/js-translation-bundle/Resources/views/getTranslations.json.twig");
    }
}
