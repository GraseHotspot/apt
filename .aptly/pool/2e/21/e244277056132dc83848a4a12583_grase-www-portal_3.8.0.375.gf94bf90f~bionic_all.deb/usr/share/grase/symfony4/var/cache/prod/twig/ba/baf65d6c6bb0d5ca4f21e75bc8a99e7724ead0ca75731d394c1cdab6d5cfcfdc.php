<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html.twig */
class __TwigTemplate_75ec673df4a7051d7ae2e4f0373a1e14a4b4a676ea1ac67483f5245055a6c8a5 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_title' => [$this, 'block_page_title'],
            'page_subtitle' => [$this, 'block_page_subtitle'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'content_header' => [$this, 'block_content_header'],
            'content' => [$this, 'block_content'],
            'status_table' => [$this, 'block_status_table'],
            'netdata' => [$this, 'block_netdata'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html.twig", "index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_page_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.title", [], "messages");
    }

    // line 7
    public function block_page_subtitle($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 10
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 11
        echo "    ";
        if (($context["netdataEnabled"] ?? null)) {
            // line 12
            echo "    <script>var netdataNoBootstrap = true;</script>
    ";
            // line 14
            echo "    <script type=\"text/javascript\" src=\"http://localhost:19999/dashboard.js\"></script>
    ";
            // line 18
            echo "    ";
        }
        // line 19
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
    }

    // line 23
    public function block_content_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 24
        echo "    <h1>";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.title", [], "messages");
        echo "</h1>
";
    }

    // line 27
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 28
        echo "    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-lg-6\">
                <div class=\"card\">
                    ";
        // line 32
        $this->displayBlock("status_table", $context, $blocks);
        echo "
                </div>
            </div>
            ";
        // line 35
        if (($context["netdataEnabled"] ?? null)) {
            // line 36
            echo "            <div class=\"col-lg-6\">
                <div class=\"card\">
                    ";
            // line 38
            $this->displayBlock("netdata", $context, $blocks);
            echo "
                </div>
            </div>
            ";
        }
        // line 42
        echo "        </div>
    </div>

";
    }

    // line 47
    public function block_status_table($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 48
        echo "    <div class=\"card-header\">
        <h3 class=\"card-title\">grase.status.card.status.title</h3>
    </div>
    <div class=\"card-body p-0\">
    <table id=\"groupsTable\" class=\"table table-bordered table-hover\">
        <tbody>
        <tr>
            <th class=\"header\" colspan=\"3\">";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.header.device_information", [], "messages");
        echo "</th>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 58
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.model_name", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 59
        echo twig_escape_filter($this->env, ($context["applicationName"] ?? null), "html", null, true);
        echo "</td>
        </tr>

        <tr>
            <td class=\"title\">";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.hostname", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 64
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "hostname", [], "any", false, false, false, 64), "html", null, true);
        echo "</td>
        </tr>

        <tr>
            <td class=\"title\">";
        // line 68
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.httpserver", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 69
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "httpd", [], "any", false, false, false, 69), "software", [], "any", false, false, false, 69), "html", null, true);
        echo " via ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "httpd", [], "any", false, false, false, 69), "gateway", [], "any", false, false, false, 69), "html", null, true);
        echo "</td>
        </tr>


        <tr>
            <td class=\"title\">";
        // line 74
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.uptime", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 75
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "uptime", [], "any", false, false, false, 75), "html", null, true);
        echo "</td>
        </tr>

        <tr>
            <td class=\"title\">";
        // line 79
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.current_time", [], "messages");
        echo "</td>
            <td>";
        // line 80
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "r"), "html", null, true);
        echo "</td>
            <td></td>
        </tr>

        <tr>
            <td class=\"title\">";
        // line 85
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.hardware_version", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 86
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "cpu", [], "any", false, false, false, 86), "model", [], "any", false, false, false, 86), "html", null, true);
        echo " @";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "cpu", [], "any", false, false, false, 86), "speed", [], "any", false, false, false, 86), "html", null, true);
        echo "MHz</td>
        </tr>

        <tr>
            <td class=\"title\">";
        // line 90
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.app_version", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 91
        echo twig_escape_filter($this->env, ($context["shivas_app_version"] ?? null), "html", null, true);
        echo "</td>
        </tr>

        <tr>
            <td class=\"title\">";
        // line 95
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.app_url", [], "messages");
        echo "</td>
            <td colspan=\"2\"><a href=\"https://grasehotspot.org\">GRASE Hotspot</a></td>
        </tr>


        <tr>
            <th class=\"header\" colspan=\"3\">";
        // line 101
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.header.lan", [], "messages");
        echo "</th>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 104
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.ipaddress", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 105
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "lan", [], "any", false, false, false, 105), "ipaddress", [], "any", false, false, false, 105), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 108
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.netmask", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 109
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "lan", [], "any", false, false, false, 109), "netmask", [], "any", false, false, false, 109), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 112
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.mac", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 113
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "lan", [], "any", false, false, false, 113), "mac", [], "any", false, false, false, 113)), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 116
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.net_interface", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 117
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "lan", [], "any", false, false, false, 117), "iface", [], "any", false, false, false, 117), "html", null, true);
        echo "</td>
        </tr>

        <tr>
            <th class=\"header\" colspan=\"3\">";
        // line 121
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.header.wan", [], "messages");
        echo "</th>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 124
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.ipaddress", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 125
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "wan", [], "any", false, false, false, 125), "ipaddress", [], "any", false, false, false, 125), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 128
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.netmask", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 129
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "wan", [], "any", false, false, false, 129), "netmask", [], "any", false, false, false, 129), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 132
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.gateway", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 133
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "wan", [], "any", false, false, false, 133), "gateway", [], "any", false, false, false, 133), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 136
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.dns_primary", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 137
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "wan", [], "any", false, false, false, 137), "dnsPrimary", [], "any", false, false, false, 137), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 140
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.dns_secondary", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 141
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "wan", [], "any", false, false, false, 141), "dnsSecondary", [], "any", false, false, false, 141), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 144
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.mac", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 145
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "wan", [], "any", false, false, false, 145), "mac", [], "any", false, false, false, 145)), "html", null, true);
        echo "</td>
        </tr>
        <tr>
            <td class=\"title\">";
        // line 148
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.status.card.net_interface", [], "messages");
        echo "</td>
            <td colspan=\"2\">";
        // line 149
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["systemInfo"] ?? null), "wan", [], "any", false, false, false, 149), "iface", [], "any", false, false, false, 149), "html", null, true);
        echo "</td>
        </tr>
        </tbody>
    </table>
    </div>
";
    }

    // line 156
    public function block_netdata($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 157
        echo "    <div class=\"card-header\">
        <h3 class=\"card-title\">Netdata</h3>
    </div>
    <div class=\"card-body\">
        <div class=\"tab-content\">

        <div data-netdata=\"system.cpu\"
             data-chart-library=\"gauge\"
             data-width=\"25%\"
             data-after=\"-300\"
             data-points=\"150\"
             data-units=\"%\"
        >
        </div>
        <div data-netdata=\"system.ram\"
             data-dimensions=\"used|buffers|active|wired\"
             data-gauge-max-value=\"100\"
             data-append-options=\"percentage\"
             data-chart-library=\"gauge\"
             data-units=\"%\"
             data-width=\"25%\"
             data-after=\"-300\"
             data-points=\"150\"
        >
        </div>
        <div data-netdata=\"system.net\"
             data-after=\"-300\"
             data-before=\"0\"
        ></div>
            <div data-netdata=\"system.ip\"
                 data-after=\"-300\"
                 data-before=\"0\"
            ></div>

        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  379 => 157,  375 => 156,  365 => 149,  361 => 148,  355 => 145,  351 => 144,  345 => 141,  341 => 140,  335 => 137,  331 => 136,  325 => 133,  321 => 132,  315 => 129,  311 => 128,  305 => 125,  301 => 124,  295 => 121,  288 => 117,  284 => 116,  278 => 113,  274 => 112,  268 => 109,  264 => 108,  258 => 105,  254 => 104,  248 => 101,  239 => 95,  232 => 91,  228 => 90,  219 => 86,  215 => 85,  207 => 80,  203 => 79,  196 => 75,  192 => 74,  182 => 69,  178 => 68,  171 => 64,  167 => 63,  160 => 59,  156 => 58,  150 => 55,  141 => 48,  137 => 47,  130 => 42,  123 => 38,  119 => 36,  117 => 35,  111 => 32,  105 => 28,  101 => 27,  94 => 24,  90 => 23,  83 => 19,  80 => 18,  77 => 14,  74 => 12,  71 => 11,  67 => 10,  61 => 7,  56 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "index.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/index.html.twig");
    }
}
