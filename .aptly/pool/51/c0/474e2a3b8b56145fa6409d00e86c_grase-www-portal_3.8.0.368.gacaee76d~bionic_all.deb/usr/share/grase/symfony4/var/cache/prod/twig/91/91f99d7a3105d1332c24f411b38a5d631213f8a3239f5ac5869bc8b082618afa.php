<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* monitorSessions.html.twig */
class __TwigTemplate_d5e0d4d194b3d2e13bd0e0ae0d404c083f77814b0cfa35c47a08a5484cec9832 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_title' => [$this, 'block_page_title'],
            'page_subtitle' => [$this, 'block_page_subtitle'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html.twig", "monitorSessions.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_page_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Sessions", [], "messages");
    }

    // line 7
    public function block_page_subtitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 8
        echo "
";
    }

    // line 11
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        echo "
    <div class=\"col-xs-12\">
        <div class=\"box\">
            <div class=\"box-header\">
                <h3 class=\"box-title\">";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Active Sessions", [], "messages");
        echo "</h3>
            </div>
            <div class=\"box-body\">
                <table id=\"groupsTable\" class=\"dataTable table table-bordered table-hover\"
                       data-paging=\"true\" data-page-length=\"10\" data-searching=\"true\"
                       data-ordering=\"true\" data-info=\"true\" data-autowidth=\"true\">
                    <thead>
                    <tr>
                        <th>";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Start Time", [], "messages");
        echo "</th>
                        <th>";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Stop Time", [], "messages");
        echo "</th>
                        <th>";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Session Time", [], "messages");
        echo "</th>
                        <th>";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("IP Address", [], "messages");
        echo "</th>
                        <th>";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("MAC Address", [], "messages");
        echo "</th>
                        <th>";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Username", [], "messages");
        echo "</th>
                        <th>";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Data Usage", [], "messages");
        echo "</th>
                        <th>";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Account Comment", [], "messages");
        echo "</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 36
        echo "                    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["activeSessions"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["session"]) {
            // line 37
            echo "                        <tr>
                            <td>";
            // line 38
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, twig_get_attribute($this->env, $this->source, $context["session"], "acctstarttime", [], "any", false, false, false, 38), "medium", "short"), "html", null, true);
            echo "</td>
                            <td><a data-toggle=\"tooltip\" title='";
            // line 39
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.session.tooltip.terminatecause", ["terminatecause" => twig_get_attribute($this->env, $this->source, $context["session"], "acctterminatecause", [], "any", false, false, false, 39)], "messages");
            echo "'>";
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, twig_get_attribute($this->env, $this->source, $context["session"], "acctstoptime", [], "any", false, false, false, 39), "medium", "short"), "html", null, true);
            echo "</a></td>
                            <td data-order=\"";
            // line 40
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["session"], "acctsessiontime", [], "any", false, false, false, 40), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["session"], "displayAccountSessionTime", [], "any", false, false, false, 40), "html", null, true);
            echo "</td>
                            <td>";
            // line 41
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["session"], "framedipaddress", [], "any", false, false, false, 41), "html", null, true);
            echo "</td>
                            <td>";
            // line 42
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["session"], "callingstationid", [], "any", false, false, false, 42), "html", null, true);
            echo "</td>
                            <td>

                                ";
            // line 45
            if (( !twig_get_attribute($this->env, $this->source, $context["session"], "framedipaddress", [], "any", false, false, false, 45) && twig_get_attribute($this->env, $this->source, $context["session"], "servicetype", [], "any", false, false, false, 45))) {
                // line 46
                echo "                                <a title=\"";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.session.tooltip.captive.portal.config.login", [], "messages");
                echo "\">
                                    ";
                // line 47
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["session"], "servicetype", [], "any", false, false, false, 47), "html", null, true);
                echo "
                                </a>
                                ";
            } else {
                // line 50
                echo "                                    <a href=\"";
                echo "\">";
                (((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["session"], "user", [], "any", false, true, false, 50), "username", [], "any", true, true, false, 50) &&  !(null === twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["session"], "user", [], "any", false, true, false, 50), "username", [], "any", false, false, false, 50)))) ? (print (twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["session"], "user", [], "any", false, true, false, 50), "username", [], "any", false, false, false, 50), "html", null, true))) : (print ("")));
                echo "</a>
                                    ";
                // line 52
                echo "                                ";
            }
            // line 53
            echo "

                            </td>
                            <td>
                                <a data-toggle=\"tooltip\" data-html=\"true\" title=\"&#x2193;";
            // line 57
            echo twig_escape_filter($this->env, $this->extensions['Twig_Extensions_Extension_Number']->format_bytes(twig_get_attribute($this->env, $this->source, $context["session"], "acctinputoctets", [], "any", false, false, false, 57)), "html", null, true);
            echo "<br/> &#x2191;";
            echo twig_escape_filter($this->env, $this->extensions['Twig_Extensions_Extension_Number']->format_bytes(twig_get_attribute($this->env, $this->source, $context["session"], "acctoutputoctets", [], "any", false, false, false, 57)), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['Twig_Extensions_Extension_Number']->format_bytes(twig_get_attribute($this->env, $this->source, $context["session"], "acctTotalOctets", [], "any", false, false, false, 57)), "html", null, true);
            echo "</a>


                            </td>
                            <td>";
            // line 61
            echo twig_escape_filter($this->env, twig_truncate_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["session"], "user", [], "any", false, false, false, 61), "comment", [], "any", false, false, false, 61), 50), "html", null, true);
            echo "</td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['session'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 64
        echo "                    </tbody>
                </table>
            </div>

        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "monitorSessions.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  204 => 64,  195 => 61,  184 => 57,  178 => 53,  175 => 52,  169 => 50,  163 => 47,  158 => 46,  156 => 45,  150 => 42,  146 => 41,  140 => 40,  134 => 39,  130 => 38,  127 => 37,  122 => 36,  115 => 31,  111 => 30,  107 => 29,  103 => 28,  99 => 27,  95 => 26,  91 => 25,  87 => 24,  76 => 16,  70 => 12,  66 => 11,  61 => 8,  57 => 7,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "monitorSessions.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/monitorSessions.html.twig");
    }
}
