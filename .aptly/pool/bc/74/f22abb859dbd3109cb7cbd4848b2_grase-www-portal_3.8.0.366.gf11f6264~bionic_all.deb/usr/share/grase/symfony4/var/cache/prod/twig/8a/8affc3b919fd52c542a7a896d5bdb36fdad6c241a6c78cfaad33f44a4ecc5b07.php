<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user_edit.html.twig */
class __TwigTemplate_c8693605b53a9d1b0afc9c3e2d3492b59b3c67f06e85b603e3d8967196d0b472 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_title' => [$this, 'block_page_title'],
            'page_subtitle' => [$this, 'block_page_subtitle'],
            'content' => [$this, 'block_content'],
            'javascripts_inline' => [$this, 'block_javascripts_inline'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html.twig", "user_edit.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_page_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Edit User", [], "messages");
    }

    // line 7
    public function block_page_subtitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["group"] ?? null), "name", [], "any", false, false, false, 8), "html", null, true);
        echo "
";
    }

    // line 11
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        echo "
    <div class=\"col-xs-12\">
        <div class=\"card\">
            <div class=\"card-header\">
                <h3 class=\"card-title\">";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Edit User", [], "messages");
        echo "</h3>
            </div>
            <div class=\"card-body\">
                ";
        // line 19
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["user_form"] ?? null), 'form_start');
        echo "

                <div class=\"my-custom-class-for-errors\">
                    ";
        // line 22
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["user_form"] ?? null), 'errors');
        echo "
                </div>

                <div class=\"form-row\">
                    <div class=\"col-xs-12 col-lg-6\">
                        ";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["user_form"] ?? null), "username", [], "any", false, false, false, 27), 'row');
        echo "
                        <div class=\"form-group\">
                            ";
        // line 29
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["user_form"] ?? null), "password", [], "any", false, false, false, 29), 'label');
        echo "
                            <div class=\"input-group\">
                            ";
        // line 31
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["user_form"] ?? null), "password", [], "any", false, false, false, 31), 'widget');
        echo "
                            <span class=\"input-group-append\">
                                <button type=\"button\" class=\"btn btn-dark\" id=\"generatePasswordButton\"><i class=\"material-icons small\">refresh</i> ";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Generate", [], "messages");
        echo "</button>
                            </span>
                            </div>
                            ";
        // line 36
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["user_form"] ?? null), "password", [], "any", false, false, false, 36), 'help');
        echo "
                            ";
        // line 38
        echo "                        </div>


                        ";
        // line 41
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["user_form"] ?? null), "comment", [], "any", false, false, false, 41), 'row');
        echo "
                        ";
        // line 42
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["user_form"] ?? null), "primaryGroup", [], "any", false, false, false, 42), 'row');
        echo "
                    </div>
                    <div class=\"col-xs-12 col-lg-6\">
                        ";
        // line 45
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["user_form"] ?? null), "dataLimit", [], "any", false, false, false, 45), 'row');
        echo "
                        ";
        // line 46
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["user_form"] ?? null), "timeLimit", [], "any", false, false, false, 46), 'row');
        echo "
                        ";
        // line 47
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["user_form"] ?? null), "lockMessage", [], "any", false, false, false, 47), 'row');
        echo "
                        ";
        // line 48
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["user_form"] ?? null), "save", [], "any", false, false, false, 48), 'row');
        echo "
                    </div>
                </div>

                ";
        // line 52
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["user_form"] ?? null), 'rest');
        echo "
                ";
        // line 53
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["user_form"] ?? null), 'form_end');
        echo "
            </div>

            ";
        // line 56
        if ((isset($context["user_reset_expiry_form"]) || array_key_exists("user_reset_expiry_form", $context))) {
            // line 57
            echo "            <div class=\"card-body\">
                ";
            // line 58
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["user_reset_expiry_form"] ?? null), 'form_start');
            echo "
                <div class=\"my-custom-class-for-errors\">
                    ";
            // line 60
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["user_reset_expiry_form"] ?? null), 'errors');
            echo "
                </div>

                <div class=\"form-row\">
                    <div class=\"col-xs-12 col-lg-6\">
                        <div class=\"form-group\">
                            <label >";
            // line 66
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.form.user.expireAfter.label", [], "messages");
            echo "</label>
                            <input class=\"form-control\" disabled=\"disabled\"
                                   value=\"";
            // line 68
            if (twig_get_attribute($this->env, $this->source, ($context["user"] ?? null), "expireAfter", [], "any", false, false, false, 68)) {
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["user"] ?? null), "expireAfter", [], "any", false, false, false, 68), "html", null, true);
            } else {
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.form.user.expireAfter.none", [], "messages");
            }
            echo "\">
                        </div>
                        ";
            // line 70
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["user_reset_expiry_form"] ?? null), "expiry", [], "any", false, false, false, 70), 'row');
            echo "
                        ";
            // line 71
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["user_reset_expiry_form"] ?? null), 'rest');
            echo "
                        ";
            // line 72
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["user_reset_expiry_form"] ?? null), 'form_end');
            echo "
                    </div>

                    <div class=\"col-xs-12 col-lg-6\">
                        <h2 >";
            // line 76
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.form.user.delete.label", [], "messages");
            echo "</h2>
                        <p>";
            // line 77
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.form.user.delete.warning", [], "messages");
            echo "</p>
                        ";
            // line 78
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["user_delete_form"] ?? null), 'form');
            echo "
                    </div>
                </div>

            </div>
            ";
        }
        // line 84
        echo "
        </div>
    </div>

";
    }

    // line 90
    public function block_javascripts_inline($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 91
        echo "    <script>
        function pageJs(\$) {
            // Ensure that when a user types customs values we clear the dropdowns
            \$('#user_dataLimit_dataLimitCustom').change(function () {
                if (\$('#user_dataLimit_dataLimitCustom').val() != '') {
                    \$('#user_dataLimit_dataLimitDropdown').val('');
                }
            });
            \$('#user_timeLimit_timeLimitCustom').change(function () {
                if (\$('#user_timeLimit_timeLimitCustom').val() != '') {
                    \$('#user_timeLimit_timeLimitDropdown').val('');
                }
            });

            // Allow the user to auto generate a new password for the account
            \$('#generatePasswordButton').click(function () {
                \$.ajax(Routing.generate('grase_api_generate_password', null, true))
                    .done(function(data) {
                        \$('#user_password').val(data);
                    });

            });

            // Ensure we confirm before deleting the user
            \$('#user_delete_delete').click(function () {
                return confirm('";
        // line 116
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.form.user.submit.delete.confirm.%username%", ["%username%" => twig_get_attribute($this->env, $this->source, ($context["user"] ?? null), "username", [], "any", false, false, false, 116)], "messages");
        echo "');
            })
        };
    </script>
";
    }

    public function getTemplateName()
    {
        return "user_edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  271 => 116,  244 => 91,  240 => 90,  232 => 84,  223 => 78,  219 => 77,  215 => 76,  208 => 72,  204 => 71,  200 => 70,  191 => 68,  186 => 66,  177 => 60,  172 => 58,  169 => 57,  167 => 56,  161 => 53,  157 => 52,  150 => 48,  146 => 47,  142 => 46,  138 => 45,  132 => 42,  128 => 41,  123 => 38,  119 => 36,  113 => 33,  108 => 31,  103 => 29,  98 => 27,  90 => 22,  84 => 19,  78 => 16,  72 => 12,  68 => 11,  62 => 8,  58 => 7,  53 => 4,  49 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "user_edit.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/user_edit.html.twig");
    }
}
