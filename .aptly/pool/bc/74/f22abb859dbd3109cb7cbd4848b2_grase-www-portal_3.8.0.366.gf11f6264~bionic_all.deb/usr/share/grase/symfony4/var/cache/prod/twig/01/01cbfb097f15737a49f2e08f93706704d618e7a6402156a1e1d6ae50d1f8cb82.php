<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* advancedSettings.html.twig */
class __TwigTemplate_ba3dec1ef783c01bb742bd17a318c8362e9d092a4e0ac33801caa059f5331588 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_title' => [$this, 'block_page_title'],
            'page_subtitle' => [$this, 'block_page_subtitle'],
            'javascripts_inline' => [$this, 'block_javascripts_inline'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html.twig", "advancedSettings.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_page_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Advanced Settings", [], "messages");
    }

    // line 7
    public function block_page_subtitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 8
        echo "
";
    }

    // line 11
    public function block_javascripts_inline($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        echo "<script>
    function render_link(data, type, row, meta) {
        console.log(data);
        return '<a href=\"'+ Routing.generate(\"grase_advanced_settings_edit\", {setting: data }) +'\">'+data+'</a>';
    }

    function pageJs(\$) {

        \$('#advancedSettings').DataTable(
            {
                //retrieve: true,
                destroy: true,
                \"columnDefs\": [{
                    \"render\": render_link,
                    \"targets\": 0
                }]
            }
        );
    }
</script>
";
    }

    // line 34
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 35
        echo "
    <div class=\"col-xs-12\">
        <div class=\"card\">
            <div class=\"card-header\">
                <h3 class=\"card-title\">";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Advanced Settings", [], "messages");
        echo "</h3>
            </div>
            <div class=\"card-body\">
                ";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.advancedSettings.warning.long", [], "messages");
        // line 43
        echo "                <div class=\"alert-danger alert\">
                    <strong>";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.advancedSettings.warning.caution", [], "messages");
        echo "</strong><br/>
                </div>

                <table id=\"advancedSettings\" class=\"table table-bordered table-hover dataTable\"
                       data-paging=\"true\" data-page-length=\"10\" data-searching=\"true\"
                       data-ordering=\"true\" data-info=\"true\" data-autowidth=\"true\"
                       data-ajax='{\"url\": \"";
        // line 50
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("api_settings_get_collection", ["pagination" => false]);
        echo "\", \"dataSrc\": \"\"}'
                       data-columns='[ {\"data\": \"name\"}, {\"data\": \"value\"} ]'

                >
                    <thead>
                    <tr>
                        <th>";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Name", [], "messages");
        echo "</th>
                        <th>";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Value", [], "messages");
        echo "</th>
                    </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
            </div>

        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "advancedSettings.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 57,  134 => 56,  125 => 50,  116 => 44,  113 => 43,  111 => 42,  105 => 39,  99 => 35,  95 => 34,  71 => 12,  67 => 11,  62 => 8,  58 => 7,  53 => 4,  49 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "advancedSettings.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/advancedSettings.html.twig");
    }
}
