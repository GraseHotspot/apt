<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* layout.html.twig */
class __TwigTemplate_61002b806155cffafacb8f6abe9054ca39ecdffc4f080cef40d7818d2e2d4c0a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'sidebar' => [$this, 'block_sidebar'],
            'page_content_wrapper' => [$this, 'block_page_content_wrapper'],
            'flash_messages' => [$this, 'block_flash_messages'],
            'content_header' => [$this, 'block_content_header'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "layout.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Grase";
    }

    // line 5
    public function block_sidebar($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "    <!-- Main Sidebar Container -->
    <aside class=\"main-sidebar sidebar-dark-primary elevation-4\">
        <!-- Brand Logo -->
        <a href=\"";
        // line 9
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("grase_radmin_homepage");
        echo "\" class=\"brand-link\">
            <img src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/images/grase.png"), "html", null, true);
        echo "\" alt=\"Grase Logo\" class=\"brand-image img-circle elevation-3\"
                 style=\"opacity: .8\">
            <span class=\"brand-text font-weight-light\">GRASE <span class=\"text-muted small\">v";
        // line 12
        echo twig_escape_filter($this->env, ($context["shivas_app_version"] ?? null), "html", null, true);
        echo "</span></span>
        </a>

        <!-- Sidebar -->
        <div class=\"sidebar\">
            <!-- Sidebar user panel (optional) -->
            ";
        // line 18
        if (twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 18)) {
            // line 19
            echo "            <div class=\"user-panel mt-3 pb-3 mb-3 d-flex\">

                <div class=\"image\">
                    ";
            // line 23
            echo "                    <img src=\"https://ui-avatars.com/api/?background=0D8ABC&color=fff&size=160&name=";
            echo twig_escape_filter($this->env, twig_first($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 23), "username", [], "any", false, false, false, 23)), "html", null, true);
            echo "\" class=\"img-circle elevation-2\" alt=\"User Image\">
                </div>
                <div class=\"info\">
                    <a class=\"d-block\"> ";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 26), "username", [], "any", false, false, false, 26), "html", null, true);
            echo "</a>
                </div>
            </div>
            ";
        }
        // line 30
        echo "
            <!-- Sidebar Menu -->
            <nav class=\"mt-2\">
                ";
        // line 33
        echo $this->extensions['Pd\MenuBundle\Twig\MenuExtension']->renderMenu("App\\Menu\\MainMenu", ["template" => "pdmenu.html.twig", "currentClass" => "active menu-open", "iconTemplate" => "<i class=\"material-icons nav-icon\">itext</i>"]);
        // line 38
        echo "
            </nav>
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>




";
    }

    // line 50
    public function block_page_content_wrapper($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 51
        echo "
    ";
        // line 52
        $this->displayBlock('flash_messages', $context, $blocks);
        // line 64
        echo "
    <!-- Content Header (Page header) -->
    <div class=\"content-header\">
        ";
        // line 67
        $this->displayBlock('content_header', $context, $blocks);
        // line 68
        echo "    </div>


    <!-- Content -->
    <div class=\"content\">
        ";
        // line 73
        $this->displayBlock('content', $context, $blocks);
        // line 74
        echo "    </div>

";
    }

    // line 52
    public function block_flash_messages($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 53
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "flashes", [], "any", false, false, false, 53));
        foreach ($context['_seq'] as $context["label"] => $context["messages"]) {
            // line 54
            echo "            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 55
                echo "                <div class=\"alert alert-";
                echo twig_escape_filter($this->env, $context["label"], "html", null, true);
                echo " alert-dismissible fade show\" role=\"alert\">
                    ";
                // line 56
                echo twig_escape_filter($this->env, $context["message"], "html", null, true);
                echo "
                    <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">
                        <span aria-hidden=\"true\">&times;</span>
                    </button>
                </div>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 62
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['label'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 63
        echo "    ";
    }

    // line 67
    public function block_content_header($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 73
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  205 => 73,  199 => 67,  195 => 63,  189 => 62,  177 => 56,  172 => 55,  167 => 54,  162 => 53,  158 => 52,  152 => 74,  150 => 73,  143 => 68,  141 => 67,  136 => 64,  134 => 52,  131 => 51,  127 => 50,  113 => 38,  111 => 33,  106 => 30,  99 => 26,  92 => 23,  87 => 19,  85 => 18,  76 => 12,  71 => 10,  67 => 9,  62 => 6,  58 => 5,  51 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "layout.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/layout.html.twig");
    }
}
