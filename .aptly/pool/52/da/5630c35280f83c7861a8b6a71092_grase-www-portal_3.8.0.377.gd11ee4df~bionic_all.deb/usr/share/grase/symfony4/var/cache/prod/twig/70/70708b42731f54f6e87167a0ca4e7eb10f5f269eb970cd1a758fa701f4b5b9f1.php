<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @PdMenu/Default/menu.html.twig */
class __TwigTemplate_01026faee4959228135cba9f7a90d664325a9ca589016ea431133d65d75ba869 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'menu_begin' => [$this, 'block_menu_begin'],
            'menu_item' => [$this, 'block_menu_item'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "@PdMenu/Default/menuBase.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@PdMenu/Default/menuBase.html.twig", "@PdMenu/Default/menu.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_menu_begin($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 5
        echo "    <ul id=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "id", [], "any", false, false, false, 5), "html", null, true);
        echo "\" ";
        echo $this->extensions['Pd\MenuBundle\Twig\MenuExtension']->arrayToAttr(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "childAttr", [], "any", false, false, false, 5), ["class" => "pd-menu"], ($context["options"] ?? null));
        echo ">
        ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "child", [], "any", false, false, false, 6));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["depth"]) {
            // line 7
            echo "            ";
            $context["menu"] = $context["depth"];
            // line 8
            echo "            ";
            $this->displayBlock("menu_item", $context, $blocks);
            echo "
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['depth'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 10
        echo "    </ul>
";
    }

    // line 14
    public function block_menu_item($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 15
        echo "    <li ";
        echo $this->extensions['Pd\MenuBundle\Twig\MenuExtension']->arrayToAttr(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "listAttr", [], "any", false, false, false, 15), [], ($context["options"] ?? null));
        echo ">
        ";
        // line 17
        echo "        ";
        if (twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "link", [], "any", false, false, false, 17)) {
            // line 18
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "link", [], "any", false, false, false, 18), "html", null, true);
            echo "\" ";
            echo $this->extensions['Pd\MenuBundle\Twig\MenuExtension']->arrayToAttr(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "linkAttr", [], "any", false, false, false, 18), [], ($context["options"] ?? null));
            echo ">
                ";
            // line 19
            if (twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "extra", [0 => "label_icon"], "method", false, false, false, 19)) {
                // line 20
                echo "                    ";
                echo twig_replace_filter(twig_get_attribute($this->env, $this->source, ($context["options"] ?? null), "iconTemplate", [], "any", false, false, false, 20), ["itext" => twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "extra", [0 => "label_icon"], "method", false, false, false, 20)]);
                echo "
                ";
            }
            // line 22
            echo "                <span ";
            echo $this->extensions['Pd\MenuBundle\Twig\MenuExtension']->arrayToAttr(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "labelAttr", [], "any", false, false, false, 22), [], ($context["options"] ?? null));
            echo ">
                    ";
            // line 23
            echo ((twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "extra", [0 => "label_translate", 1 => true], "method", false, false, false, 23)) ? ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "label", [], "any", false, false, false, 23), [], twig_get_attribute($this->env, $this->source, ($context["options"] ?? null), "trans_domain", [], "any", false, false, false, 23))) : (twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "label", [], "any", false, false, false, 23)));
            echo "
                </span>
                ";
            // line 25
            echo twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "labelAfterHtml", [], "any", false, false, false, 25);
            echo "
            </a>
            ";
            // line 27
            echo twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "linkAfterHtml", [], "any", false, false, false, 27);
            echo "
        ";
        } else {
            // line 29
            echo "            ";
            if (twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "extra", [0 => "label_icon"], "method", false, false, false, 29)) {
                // line 30
                echo "                ";
                echo twig_replace_filter(twig_get_attribute($this->env, $this->source, ($context["options"] ?? null), "iconTemplate", [], "any", false, false, false, 30), ["itext" => twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "extra", [0 => "label_icon"], "method", false, false, false, 30)]);
                echo "
            ";
            }
            // line 32
            echo "            <span ";
            echo $this->extensions['Pd\MenuBundle\Twig\MenuExtension']->arrayToAttr(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "labelAttr", [], "any", false, false, false, 32), [], ($context["options"] ?? null));
            echo ">
                    ";
            // line 33
            echo ((twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "extra", [0 => "label_translate", 1 => true], "method", false, false, false, 33)) ? ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "label", [], "any", false, false, false, 33), [], twig_get_attribute($this->env, $this->source, ($context["options"] ?? null), "trans_domain", [], "any", false, false, false, 33))) : (twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "label", [], "any", false, false, false, 33)));
            echo "
            </span>
            ";
            // line 35
            echo twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "labelAfterHtml", [], "any", false, false, false, 35);
            echo "
            ";
            // line 36
            echo twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "linkAfterHtml", [], "any", false, false, false, 36);
            echo "
        ";
        }
        // line 38
        echo "
        ";
        // line 40
        echo "        ";
        if (twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "child", [], "any", false, false, false, 40))) {
            // line 41
            echo "            <ul ";
            echo $this->extensions['Pd\MenuBundle\Twig\MenuExtension']->arrayToAttr(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "childAttr", [], "any", false, false, false, 41), [], ($context["options"] ?? null));
            echo ">
                ";
            // line 42
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["menu"] ?? null), "child", [], "any", false, false, false, 42));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["depth"]) {
                // line 43
                echo "                    ";
                $context["menu"] = $context["depth"];
                // line 44
                echo "                    ";
                $this->displayBlock("menu_item", $context, $blocks);
                echo "
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['depth'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 46
            echo "            </ul>
        ";
        }
        // line 48
        echo "    </li>
";
    }

    public function getTemplateName()
    {
        return "@PdMenu/Default/menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  227 => 48,  223 => 46,  206 => 44,  203 => 43,  186 => 42,  181 => 41,  178 => 40,  175 => 38,  170 => 36,  166 => 35,  161 => 33,  156 => 32,  150 => 30,  147 => 29,  142 => 27,  137 => 25,  132 => 23,  127 => 22,  121 => 20,  119 => 19,  112 => 18,  109 => 17,  104 => 15,  100 => 14,  95 => 10,  78 => 8,  75 => 7,  58 => 6,  51 => 5,  47 => 4,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@PdMenu/Default/menu.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/vendor/appaydin/pd-menu/Resources/views/Default/menu.html.twig");
    }
}
