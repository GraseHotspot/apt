<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* uamLogin.html.twig */
class __TwigTemplate_4d161487c9973f9dc6cde6acde7c85b5e0deb58f68c21744e07bbc3a144958d4 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'navbar' => [$this, 'block_navbar'],
            'bodyclass' => [$this, 'block_bodyclass'],
            'body' => [$this, 'block_body'],
            'footer' => [$this, 'block_footer'],
            'javascripts' => [$this, 'block_javascripts'],
            'stylesheets' => [$this, 'block_stylesheets'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "uamLogin.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_navbar($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 6
    public function block_bodyclass($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "hold-transition login-page layout-footer-fixed";
    }

    // line 8
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 9
        echo "<div class=\"wrapper\">
    <div class=\"d-flex flex-column h-100  justify-content-center\">
        <div class=\"login-box d-flex align-items-center flex-column login-box-uam\">
            <div class=\"login-logo login-logo-uam\">
                <img src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/images/grase.png"), "html", null, true);
        echo "\" height=\"100px\"/><br/><a><b>Grase</b>Hotspot</a>
            </div><!-- /.login-logo -->

            <!-- Voucher Error messages (not found, expired, etc) will be displayed using this variable - do not remove -->
            <div class=\"\" id=\"errormessages\" style=\"margin-top: 1em; max-width: 300px; text-align: center;\"></div>

            ";
        // line 19
        if (($context["freeLoginEnabled"] ?? null)) {
            // line 20
            echo "            <div class=\"card\" id=\"tosaccept\">
                <div class=\"card-header\">
                    <h3 class=\"card-title text-center\">";
            // line 22
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Free Login", [], "messages");
            echo "</h3>
                </div>
                <div class=\"login-box-body card-body\">
                    <form id=\"tosaccept_form\">
                        <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">";
            // line 26
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Free Login", [], "messages");
            echo "</button>
                    </form>


                    ";
            // line 41
            echo "
                </div><!-- /.login-box-body -->
            </div>
            ";
        }
        // line 45
        echo "            <div class=\"card\" id=\"loginform\">
                <div class=\"card-header\">
                    <h3 class=\"card-title text-center\">";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Voucher Login", [], "messages");
        echo "</h3>
                </div>
                <div class=\"login-box-body card-body\">
                    <form id=\"loginform_form\">
                        <div class=\"form-group has-feedback\">
                            <input type=\"text\" class=\"form-control\" placeholder=\"";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Username", [], "messages");
        echo "\" id=\"username\" name=\"username\" required autofocus />
                            <span class=\"glyphicon glyphicon-envelope form-control-feedback\"></span>
                        </div>
                        <div class=\"form-group has-feedback\">
                            <input type=\"password\" class=\"form-control\" placeholder=\"";
        // line 56
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Password", [], "messages");
        echo "\"  id=\"password\" name=\"password\" required/>
                            <span class=\"glyphicon glyphicon-lock form-control-feedback\"></span>
                        </div>
                        <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">";
        // line 59
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Login", [], "messages");
        echo "</button>

                    </form>
                    ";
        // line 73
        echo "
                </div><!-- /.login-box-body -->
            </div>
            <div id=\"loading\" style=\"display: none\">
                <div class=\"d-flex align-items-center flex-column\">

                <progress class=\"pure-material-progress-circular\"></progress><br/> ";
        // line 79
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Attempting Login...", [], "messages");
        // line 80
        echo "                </div>
            </div>
            <div class=\"card\" id=\"loggedin\" style=\"display: none;\">
                <div class=\"card-body\">
                    <div id=\"loggedinuserName\" style=\"display: none\"></div>
                    <div id=\"sessionTimeout\" style=\"display: none\"></div>
                    <div id=\"sessionMaxTotalOctets\" style=\"display: none\"></div>
                    ";
        // line 88
        echo "                    <br/><a class=\"btn btn-danger\" href=\"http://1.0.0.0\" id=\"logofflink\">";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Logout", [], "messages");
        echo "</a>
                    <a href=\"";
        // line 89
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("grase_uam_login");
        echo "\" class=\"btn btn-success\" target=\"grase_uam\" id='statuslink' style=\"display: none;\">";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Open Status Window", [], "messages");
        echo " <i class=\"fa fa-external-link\"></i></a>
                </div>

            </div>

            <!-- Support links box -->
            <div>
                <a href=\"";
        // line 96
        echo twig_escape_filter($this->env, ($context["supportContactLink"] ?? null), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["supportContactName"] ?? null), "html", null, true);
        echo "</a> | <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("grase_radmin_homepage");
        echo "\">";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Admin Login", [], "messages");
        echo "</a>
            </div>
        </div>

        <!-- Div to allow the fixed footer to work on small screens -->
        <div style=\"padding: 1rem\">&nbsp;</div>

        ";
        // line 103
        $this->displayBlock('footer', $context, $blocks);
        // line 104
        echo "
        ";
        // line 105
        $this->displayBlock('javascripts', $context, $blocks);
        // line 108
        echo "    </div>
</div>
";
    }

    // line 103
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->displayParentBlock("footer", $context, $blocks);
    }

    // line 105
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 106
        echo "            ";
        echo $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("uam");
        echo "
        ";
    }

    // line 113
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 114
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <style>
        .main-footer {
            margin-left: 0;
            flex-shrink: 0;
        }
        .login-box {
            flex: 1 0 auto;
        }
        html, body {
            height: 100%;
        }
    </style>
";
    }

    public function getTemplateName()
    {
        return "uamLogin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  227 => 114,  223 => 113,  216 => 106,  212 => 105,  205 => 103,  199 => 108,  197 => 105,  194 => 104,  192 => 103,  176 => 96,  164 => 89,  159 => 88,  150 => 80,  148 => 79,  140 => 73,  134 => 59,  128 => 56,  121 => 52,  113 => 47,  109 => 45,  103 => 41,  96 => 26,  89 => 22,  85 => 20,  83 => 19,  74 => 13,  68 => 9,  64 => 8,  57 => 6,  51 => 4,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "uamLogin.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/uamLogin.html.twig");
    }
}
