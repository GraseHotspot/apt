<?php

namespace Grase;


class AnonAuth
{
    public function getUsername()
    {
        return "Anon";
    }
}