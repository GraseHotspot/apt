<?php

header("Location: /grase/uam/");

?>
