./bin/console translation:update en --dump-messages --xliff-version=2.0 --force
