<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @BazingaJsTranslation/config.json.twig */
class __TwigTemplate_5a37b5a5056351e32e4e9d121499ce2b8c19e8a1a94994af2164f43d8958c17a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "{
    \"fallback\": \"";
        // line 2
        echo twig_escape_filter($this->env, ($context["fallback"] ?? null), "html", null, true);
        echo "\",
    \"defaultDomain\": \"";
        // line 3
        echo twig_escape_filter($this->env, ($context["defaultDomain"] ?? null), "html", null, true);
        echo "\"
}
";
    }

    public function getTemplateName()
    {
        return "@BazingaJsTranslation/config.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 3,  40 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@BazingaJsTranslation/config.json.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/vendor/willdurand/js-translation-bundle/Resources/views/config.json.twig");
    }
}
