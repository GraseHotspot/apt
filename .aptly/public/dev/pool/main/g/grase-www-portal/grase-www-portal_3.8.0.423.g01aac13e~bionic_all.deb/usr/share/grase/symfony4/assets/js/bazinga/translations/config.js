(function (t) {
t.fallback = 'en';
t.defaultDomain = 'js';
})(Translator);
