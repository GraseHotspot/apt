<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* network_settings.html.twig */
class __TwigTemplate_55a1d85a4e89a0913a0342bcfdd60481be69db191c7ab346cf060fde3653fdf6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_title' => [$this, 'block_page_title'],
            'content' => [$this, 'block_content'],
            'javascripts_inline' => [$this, 'block_javascripts_inline'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html.twig", "network_settings.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_page_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.network-settings.title", [], "messages");
    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 9
        echo "
    <div class=\"col-xs-12\">
        <div class=\"card\">
            <div class=\"card-header\">
                <h3 class=\"card-title\">";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.network-settings.title", [], "messages");
        echo "</h3>
            </div>
            <div class=\"card-body\">
                ";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.network-settings.information", [], "messages");
        // line 17
        echo "                ";
        // line 18
        echo "                ";
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["networkSettingsForm"] ?? null), 'form_start');
        echo "

                <div class=\"my-custom-class-for-errors\">
                    ";
        // line 21
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["networkSettingsForm"] ?? null), 'errors');
        echo "
                </div>

                <div class=\"form-row\">
                    <div class=\"col-xs-12 col-lg-6\">
                        ";
        // line 26
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["networkSettingsForm"] ?? null), "lanIpAddress", [], "any", false, false, false, 26), 'row');
        echo "
                        ";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["networkSettingsForm"] ?? null), "lanNetworkMask", [], "any", false, false, false, 27), 'row');
        echo "
                        ";
        // line 28
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["networkSettingsForm"] ?? null), "lanNetworkInterface", [], "any", false, false, false, 28), 'row');
        echo "
                        ";
        // line 29
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["networkSettingsForm"] ?? null), "wanNetworkInterface", [], "any", false, false, false, 29), 'row');
        echo "
                    </div>
                    <div class=\"col-xs-12 col-lg-6\">
                        ";
        // line 32
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["networkSettingsForm"] ?? null), "dnsServers", [], "any", false, false, false, 32), 'row');
        echo "
                        ";
        // line 33
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, ($context["networkSettingsForm"] ?? null), "bogusNxDomains", [], "any", false, false, false, 33), 'row');
        echo "
                    </div>
                </div>

                ";
        // line 37
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["networkSettingsForm"] ?? null), 'rest');
        echo "
                ";
        // line 38
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["networkSettingsForm"] ?? null), 'form_end');
        echo "
            </div>

        </div>
    </div>

";
    }

    // line 45
    public function block_javascripts_inline($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 46
        echo "    <script>

        function pageJs(\$) {

            function setup_add_dns_servers() {
                // Setup add for the DNS Servers
                var \$collectionHolder;

                // setup an \"add a tag\" link
                var \$addNewButton = \$('<a class=\"add_dnsServers_button\"><i class=\"material-icons\">add_circle</i></a>');
                var \$newLinkDiv = \$('<div></div>').append(\$addNewButton);

                // Get the div that holds the collection and add the add buttont
                \$collectionHolder = \$('#network_settings_dnsServers').append(\$newLinkDiv);

                // count the current form inputs we have (e.g. 2), use that as the new
                // index when inserting a new item (e.g. 2)
                \$collectionHolder.data('index', \$collectionHolder.find('input').length);

                \$addNewButton.on('click', function (e) {
                    // add a new tag form (see next code block)
                    addInputPrototype(\$collectionHolder, \$newLinkDiv);
                });
            }

            function setup_add_bogus_nx_servers() {
                // Setup add for the Bogus NX Domains Servers
                var \$collectionHolder;

                // setup an \"add a tag\" link
                var \$addNewButton = \$('<a class=\"add_bogusNxDomains_button\"><i class=\"material-icons\">add_circle</i></a>');
                var \$newLinkDiv = \$('<div></div>').append(\$addNewButton);

                // Get the div that holds the collection and add the add buttont
                \$collectionHolder = \$('#network_settings_bogusNxDomains').append(\$newLinkDiv);

                // count the current form inputs we have (e.g. 2), use that as the new
                // index when inserting a new item (e.g. 2)
                \$collectionHolder.data('index', \$collectionHolder.find('input').length);

                \$addNewButton.on('click', function (e) {
                    // add a new tag form (see next code block)
                    addInputPrototype(\$collectionHolder, \$newLinkDiv);
                });
            }

            function addInputPrototype(\$collectionHolder, \$newButtonElement) {
                // Get the data-prototype explained earlier
                var prototype = \$collectionHolder.data('prototype');

                // get the new index
                var index = \$collectionHolder.data('index');

                var newForm = prototype;
                // You need this only if you didn't set 'label' => false in your tags field in TaskType
                // Replace '__name__label__' in the prototype's HTML to
                // instead be a number based on how many items we have
                // newForm = newForm.replace(/__name__label__/g, index);

                // Replace '__name__' in the prototype's HTML to
                // instead be a number based on how many items we have
                newForm = newForm.replace(/__name__/g, index);

                // increase the index with one for the next item
                \$collectionHolder.data('index', index + 1);

                // Add the input before the add button
                \$newButtonElement.before(newForm);
            }

            setup_add_dns_servers();
            setup_add_bogus_nx_servers();
        }
    </script>
";
    }

    public function getTemplateName()
    {
        return "network_settings.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 46,  136 => 45,  125 => 38,  121 => 37,  114 => 33,  110 => 32,  104 => 29,  100 => 28,  96 => 27,  92 => 26,  84 => 21,  77 => 18,  75 => 17,  73 => 16,  67 => 13,  61 => 9,  57 => 8,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "network_settings.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/network_settings.html.twig");
    }
}
