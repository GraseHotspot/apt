<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* searchResults.html.twig */
class __TwigTemplate_d656f6b80b4040c93503ab42a673ce8da920f4cbeab7cdd6a4c97496c84e1a4c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_title' => [$this, 'block_page_title'],
            'page_subtitle' => [$this, 'block_page_subtitle'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html.twig", "searchResults.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_page_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.searchResults.title", [], "messages");
    }

    // line 7
    public function block_page_subtitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 8
        echo "
";
    }

    // line 11
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        echo "    <h2>";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.searchResults.title", [], "messages");
        echo "</h2>
    <div class=\"row\">

        <div class=\"col-xs-12 col-lg-6\">
            <div class=\"card\">
                <div class=\"card-header\">
                    <h3 class=\"card-title\">";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.searchResults.title.users", [], "messages");
        echo "</h3>
                </div>
                <div class=\"card-body\">
                    <table id=\"usersTable\" class=\"table table-bordered table-hover dataTable\"
                           data-paging=\"true\" data-page-length=\"10\" data-searching=\"true\"
                           data-ordering=\"true\" data-info=\"true\" data-autowidth=\"true\">
                        <thead>
                        <tr>
                            <th>";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.table.header.username", [], "messages");
        echo "</th>
                            <th>";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Last Logout", [], "messages");
        echo "</th>
                            <th>";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Group", [], "messages");
        echo "</th>
                            <th>";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Comment", [], "messages");
        echo "</th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 33
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["users"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 34
            echo "                            <tr>
                                <td>";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "username", [], "any", false, false, false, 35), "html", null, true);
            echo "<span class=\"float-right\"><a href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("grase_user_edit", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "username", [], "any", false, false, false, 35)]), "html", null, true);
            echo "\"><i class=\"fas fa-user-edit\"></i></a> <a data-toggle=\"popover\" tabindex=\"0\" data-trigger=\"focus\" title=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Password", [], "messages");
            echo "\" data-content=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "password", [], "any", false, false, false, 35), "html", null, true);
            echo "\"><i class=\"material-icons md-18 md-dark\">lock</i></a></span></td>
                                <td data-order=\"";
            // line 36
            ((twig_get_attribute($this->env, $this->source, $context["user"], "lastLogout", [], "any", false, false, false, 36)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "lastLogout", [], "any", false, false, false, 36), "U"), "html", null, true))) : (print ("")));
            echo "\">";
            if (twig_get_attribute($this->env, $this->source, $context["user"], "lastLogout", [], "any", false, false, false, 36)) {
                echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "lastLogout", [], "any", false, false, false, 36), "medium", "short"), "html", null, true);
            }
            echo "</td>
                                <td>";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "allUserGroupsNames", [], "any", false, false, false, 37), "html", null, true);
            echo "</td>
                                <td>";
            // line 38
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "comment", [], "any", false, false, false, 38), "html", null, true);
            echo "</td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "                        </tbody>
                    </table>
                </div>

            </div>
        </div>

        <div class=\"col-xs-12 col-lg-6\">
            <div class=\"card\">
                <div class=\"card-header\">
                    <h3 class=\"card-title\">";
        // line 51
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.searchResults.title.groups", [], "messages");
        echo "</h3>
                </div>
                <div class=\"card-body\">
                    <table id=\"groupsTable\" class=\"dataTable table table-bordered table-hover\"
                           data-paging=\"true\" data-page-length=\"10\" data-searching=\"true\"
                           data-ordering=\"true\" data-info=\"true\" data-autowidth=\"true\">
                        <thead>
                        <tr>
                            <th>";
        // line 59
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Name", [], "messages");
        echo "</th>
                            <th>";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Comment", [], "messages");
        echo "</th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 64
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["groups"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 65
            echo "                            <tr>
                                <td><a href=\"";
            // line 66
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("grase_users", ["group" => twig_get_attribute($this->env, $this->source, $context["group"], "name", [], "any", false, false, false, 66)]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["group"], "name", [], "any", false, false, false, 66), "html", null, true);
            echo "</a> <a href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("grase_group_edit", ["id" => twig_get_attribute($this->env, $this->source, $context["group"], "id", [], "any", false, false, false, 66)]), "html", null, true);
            echo "\"><i class=\"fas fa-edit float-right\"></i></a></td>
                                <td>";
            // line 67
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["group"], "comment", [], "any", false, false, false, 67), "html", null, true);
            echo "</td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 70
        echo "                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "searchResults.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  206 => 70,  197 => 67,  189 => 66,  186 => 65,  182 => 64,  175 => 60,  171 => 59,  160 => 51,  148 => 41,  139 => 38,  135 => 37,  127 => 36,  117 => 35,  114 => 34,  110 => 33,  103 => 29,  99 => 28,  95 => 27,  91 => 26,  80 => 18,  70 => 12,  66 => 11,  61 => 8,  57 => 7,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "searchResults.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/searchResults.html.twig");
    }
}
