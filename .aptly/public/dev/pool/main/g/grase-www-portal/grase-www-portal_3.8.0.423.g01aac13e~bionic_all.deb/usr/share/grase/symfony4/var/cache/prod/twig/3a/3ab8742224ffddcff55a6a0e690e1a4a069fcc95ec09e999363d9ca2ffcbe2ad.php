<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_cb7bda96eec60913afdad0538f04d167054a83e0e9affc0a9e29fe8e98f47527 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'bodyclass' => [$this, 'block_bodyclass'],
            'body' => [$this, 'block_body'],
            'navbar' => [$this, 'block_navbar'],
            'sidebar' => [$this, 'block_sidebar'],
            'page_content_wrapper' => [$this, 'block_page_content_wrapper'],
            'footer' => [$this, 'block_footer'],
            'footer_extra' => [$this, 'block_footer_extra'],
            'javascripts' => [$this, 'block_javascripts'],
            'javascripts_inline' => [$this, 'block_javascripts_inline'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"";
        // line 2
        echo twig_escape_filter($this->env, (($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = twig_split_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 2), "locale", [], "any", false, false, false, 2), "_")) && is_array($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4) || $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 instanceof ArrayAccess ? ($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4[0] ?? null) : null), "html", null, true);
        echo "\">
<head>
    <meta charset=\"UTF-8\">
    <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "    <link rel=\"icon\" sizes=\"16x16\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/images/grase_globe_combined.ico"), "html", null, true);
        echo "\"/>
</head>
<body class=\"";
        // line 12
        $this->displayBlock('bodyclass', $context, $blocks);
        echo "\">
";
        // line 13
        $this->displayBlock('body', $context, $blocks);
        // line 113
        echo "
</body>
</html>
";
    }

    // line 5
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Welcome!";
    }

    // line 6
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 7
        echo "        ";
        // line 8
        echo "        ";
        echo $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("app");
        echo "
    ";
    }

    // line 12
    public function block_bodyclass($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "hold-transition sidebar-mini layout-fixed";
    }

    // line 13
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 14
        echo "    <div class=\"wrapper\">
        ";
        // line 15
        $this->displayBlock('navbar', $context, $blocks);
        // line 84
        echo "
        <!-- Main Sidebar Block -->
        ";
        // line 86
        $this->displayBlock('sidebar', $context, $blocks);
        // line 87
        echo "
        <!-- Content Wrapper. Contains page content -->
        <div class=\"content-wrapper px-4 py-2\">
            ";
        // line 90
        $this->displayBlock('page_content_wrapper', $context, $blocks);
        // line 91
        echo "        </div>

        ";
        // line 93
        $this->displayBlock('footer', $context, $blocks);
        // line 103
        echo "
        ";
        // line 104
        $this->displayBlock('javascripts', $context, $blocks);
        // line 109
        echo "        ";
        $this->displayBlock('javascripts_inline', $context, $blocks);
        // line 111
        echo "    </div>
";
    }

    // line 15
    public function block_navbar($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 16
        echo "            <!-- Navbar -->
            <nav class=\"main-header navbar navbar-expand navbar-white navbar-light\">
                <!-- Left navbar links -->
                <ul class=\"navbar-nav\">
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" data-widget=\"pushmenu\" href=\"#\"><i class=\"fas fa-bars\"></i></a>
                    </li>
                    <li class=\"nav-item d-none d-sm-inline-block\">
                        <a href=\"";
        // line 24
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("grase_radmin_homepage");
        echo "\" class=\"nav-link\">Home</a>
                    </li>
                    <li class=\"nav-item d-none d-sm-inline-block\">
                        <a href=\"#\" class=\"nav-link\">Contact</a>
                    </li>
                </ul>

                <!-- SEARCH FORM -->
                <form class=\"form-inline ml-3\" method=\"post\" action=\"";
        // line 32
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("grase_global_search");
        echo "\">
                    <div class=\"input-group input-group-sm\">
                        <input name=\"search\" class=\"form-control form-control-navbar\" type=\"search\" placeholder=\"Search\"
                               aria-label=\"Search\" value=\"";
        // line 35
        echo twig_escape_filter($this->env, (((isset($context["searchTerm"]) || array_key_exists("searchTerm", $context))) ? (_twig_default_filter(($context["searchTerm"] ?? null), "")) : ("")), "html", null, true);
        echo "\">
                        <div class=\"input-group-append\">
                            <button class=\"btn btn-navbar\" type=\"submit\">
                                <i class=\"fas fa-search\"></i>
                            </button>
                        </div>
                    </div>
                </form>

                <!-- Right navbar links -->
                <ul class=\"navbar-nav ml-auto\">
                    <!-- Notifications Dropdown Menu -->
                    ";
        // line 80
        echo "                </ul>
            </nav>
            <!-- /.navbar -->
        ";
    }

    // line 86
    public function block_sidebar($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 90
    public function block_page_content_wrapper($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 93
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 94
        echo "            <footer class=\"main-footer text-center\">
                <div class=\"float-left d-none d-sm-inline-block\"><strong>";
        // line 95
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Copyright", [], "messages");
        echo " © 2008-";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " <a
                            href=\"https://grasehotspot.org\">Timothy White - GraseHotspot.org</a>.</strong></div>
                <span>";
        // line 97
        $this->displayBlock('footer_extra', $context, $blocks);
        echo "</span>
                <div class=\"float-right d-none d-sm-inline-block\">
                    <b>";
        // line 99
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Version", [], "messages");
        echo "</b> ";
        echo twig_escape_filter($this->env, ($context["shivas_app_version"] ?? null), "html", null, true);
        echo "
                </div>
            </footer>
        ";
    }

    // line 97
    public function block_footer_extra($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 104
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 105
        echo "            ";
        echo $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("app");
        echo "
            <script src=\"";
        // line 106
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/fosjsrouting/js/router.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 107
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("fos_js_routing_js", ["callback" => "fos.Router.setData"]);
        echo "\"></script>
        ";
    }

    // line 109
    public function block_javascripts_inline($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 110
        echo "        ";
    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  273 => 110,  269 => 109,  263 => 107,  259 => 106,  254 => 105,  250 => 104,  244 => 97,  234 => 99,  229 => 97,  222 => 95,  219 => 94,  215 => 93,  209 => 90,  203 => 86,  196 => 80,  181 => 35,  175 => 32,  164 => 24,  154 => 16,  150 => 15,  145 => 111,  142 => 109,  140 => 104,  137 => 103,  135 => 93,  131 => 91,  129 => 90,  124 => 87,  122 => 86,  118 => 84,  116 => 15,  113 => 14,  109 => 13,  102 => 12,  95 => 8,  93 => 7,  89 => 6,  82 => 5,  75 => 113,  73 => 13,  69 => 12,  63 => 10,  61 => 6,  57 => 5,  51 => 2,  48 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "base.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/base.html.twig");
    }
}
