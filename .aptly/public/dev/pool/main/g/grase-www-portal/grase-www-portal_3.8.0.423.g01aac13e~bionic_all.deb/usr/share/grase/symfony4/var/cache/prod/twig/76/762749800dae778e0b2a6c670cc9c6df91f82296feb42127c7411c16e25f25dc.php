<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* dnsmasqNetworkSettings.txt.twig */
class __TwigTemplate_f51bab6d78ca1b40c4cb3d6c336c49df4b0a6bf3fcb91f1269c11e47404ee5ae extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "#### This file is auto generated                              ####
#### Please do not edit it.                                   ####
#### Changes can be made in the Grase Hotspot Admin interface ####

#chilli_lanip ";
        // line 5
        echo ($context["lanIP"] ?? null);
        echo "
#chilli_wanif ";
        // line 6
        echo ($context["wanInterface"] ?? null);
        echo "
#chilli_lanif ";
        // line 7
        echo ($context["lanInterface"] ?? null);
        echo "
#chilli_network ";
        // line 8
        echo ($context["lanNetwork"] ?? null);
        echo "
#chilli_netmask ";
        // line 9
        echo ($context["lanNetmask"] ?? null);
        echo "

address=/grasehotspot.lan/";
        // line 11
        echo ($context["lanIP"] ?? null);
        echo "
address=/logout/1.0.0.0
address=/logoff/1.0.0.0

no-resolv
strict-order

expand-hosts
domain=hotspot.lan

";
        // line 21
        if ((twig_length_filter($this->env, ($context["dnsServers"] ?? null)) == 0)) {
            // line 23
            echo "#default dns servers and Cloudflare Family filter
server=1.1.1.3
server=1.0.0.3
";
        }
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["dnsServers"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["dnsServer"]) {
            // line 28
            echo "server=";
            echo $context["dnsServer"];
            echo "
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['dnsServer'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "
";
        // line 31
        if ((twig_length_filter($this->env, ($context["bogusNX"] ?? null)) > 0)) {
            // line 32
            echo "# Sometimes we get a DNS server that gives us bogus NX records, we can block them here
";
            // line 33
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["bogusNX"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["bogusNXIP"]) {
                // line 34
                echo "bogus-nxdomain=";
                echo $context["bogusNXIP"];
                echo "
";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['bogusNXIP'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        // line 37
        echo "
# last updated ";
        // line 38
        echo ($context["lastChangedTimestamp"] ?? null);
        echo "
";
    }

    public function getTemplateName()
    {
        return "dnsmasqNetworkSettings.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 38,  120 => 37,  110 => 34,  106 => 33,  103 => 32,  101 => 31,  98 => 30,  89 => 28,  85 => 27,  79 => 23,  77 => 21,  64 => 11,  59 => 9,  55 => 8,  51 => 7,  47 => 6,  43 => 5,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "dnsmasqNetworkSettings.txt.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/dnsmasqNetworkSettings.txt.twig");
    }
}
