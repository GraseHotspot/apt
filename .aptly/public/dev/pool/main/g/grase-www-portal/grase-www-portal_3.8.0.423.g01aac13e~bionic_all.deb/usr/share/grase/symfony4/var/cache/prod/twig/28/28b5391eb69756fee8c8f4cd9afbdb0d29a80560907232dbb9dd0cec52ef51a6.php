<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* login.html.twig */
class __TwigTemplate_4607387ce69fade88c561ef941ec15e493fec9a5469d3bcec07de9c855e446d2 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'navbar' => [$this, 'block_navbar'],
            'bodyclass' => [$this, 'block_bodyclass'],
            'body' => [$this, 'block_body'],
            'footer' => [$this, 'block_footer'],
            'stylesheets' => [$this, 'block_stylesheets'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "login.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_navbar($context, array $blocks = [])
    {
        $macros = $this->macros;
    }

    // line 6
    public function block_bodyclass($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "hold-transition login-page";
    }

    // line 8
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 9
        echo "    <div class=\"d-flex flex-column h-100  justify-content-center\">
        <div class=\"login-box\">
            <div class=\"login-logo\">
                <img src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("build/images/grase.png"), "html", null, true);
        echo "\" height=\"100px\"/><br/><a href=\"\"><b>Grase</b>Hotspot</a>
            </div><!-- /.login-logo -->

            ";
        // line 15
        if (($context["firstRunWizardNeeded"] ?? null)) {
            // line 16
            echo "            <!-- First run wizard warning -->
            <div class=\"card card-danger width\">
                <div class=\"card-header\">
                        <h5><i class=\"material-icons\">warning</i>";
            // line 19
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("login.first-run-wizard.warning.title", [], "messages");
            echo "</h5>
                </div>
                <div class=\"card-body\">
                    ";
            // line 22
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("login.first-run-wizard.warning.body", [], "messages");
            // line 23
            echo "                </div>
            </div>
            ";
        }
        // line 26
        echo "
            <div class=\"card\">
                <div class=\"login-box-body card-body\">
                <p class=\"login-box-msg\">Sign in to access the Admin area</p>
                ";
        // line 30
        if (($context["error"] ?? null)) {
            // line 31
            echo "                    <div class=\"alert alert-danger show\" role=\"alert\">
                        ";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["error"] ?? null), "message", [], "any", false, false, false, 32), "html", null, true);
            echo "

                    </div>
                ";
        }
        // line 36
        echo "                <form action=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("_grase_security_check");
        echo "\" method=\"post\">
                    <div class=\"form-group has-feedback\">
                        <input type=\"text\" class=\"form-control\" placeholder=\"Username\" id=\"username\" name=\"_username\" value=\"";
        // line 38
        echo twig_escape_filter($this->env, ($context["last_username"] ?? null), "html", null, true);
        echo "\" />
                        <span class=\"glyphicon glyphicon-envelope form-control-feedback\"></span>
                    </div>
                    <div class=\"form-group has-feedback\">
                        <input type=\"password\" class=\"form-control\" placeholder=\"Password\"  id=\"password\" name=\"_password\"/>
                        <span class=\"glyphicon glyphicon-lock form-control-feedback\"></span>
                    </div>
                    <button type=\"submit\" class=\"btn btn-primary btn-block btn-flat\">Sign In</button>

                </form>
                ";
        // line 59
        echo "
            </div><!-- /.login-box-body -->
            </div>
        </div>
        ";
        // line 63
        $this->displayBlock('footer', $context, $blocks);
        // line 64
        echo "    </div>
";
    }

    // line 63
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->displayParentBlock("footer", $context, $blocks);
    }

    // line 67
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 68
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <style>
        .main-footer {
            margin-left: 0;
            flex-shrink: 0;
        }
        .login-box {
            flex: 1 0 auto;
        }
        html, body {
            height: 100%;
        }
    </style>
";
    }

    public function getTemplateName()
    {
        return "login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 68,  155 => 67,  148 => 63,  143 => 64,  141 => 63,  135 => 59,  122 => 38,  116 => 36,  109 => 32,  106 => 31,  104 => 30,  98 => 26,  93 => 23,  91 => 22,  85 => 19,  80 => 16,  78 => 15,  72 => 12,  67 => 9,  63 => 8,  56 => 6,  50 => 4,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "login.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/login.html.twig");
    }
}
