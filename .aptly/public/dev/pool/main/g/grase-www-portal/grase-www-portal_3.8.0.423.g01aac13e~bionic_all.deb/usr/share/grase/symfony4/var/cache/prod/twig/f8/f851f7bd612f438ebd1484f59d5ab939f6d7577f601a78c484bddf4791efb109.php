<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* users.html.twig */
class __TwigTemplate_2612354b22bee99c4fa950aec8b7d6be7cd214d33fa8c2ed0a4c632e96f6d4a0 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_title' => [$this, 'block_page_title'],
            'page_subtitle' => [$this, 'block_page_subtitle'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("layout.html.twig", "users.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_page_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("User Accounts", [], "messages");
    }

    // line 7
    public function block_page_subtitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 8
        echo "
";
    }

    // line 11
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 12
        echo "
    <div class=\"col-xs-12\">
        <div class=\"box\">
            <div class=\"box-header\">
                <h3 class=\"box-title\">";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("User Accounts", [], "messages");
        echo "</h3>
            </div>
            <div class=\"box-body\">
                <table id=\"usersTable\" class=\"table table-bordered table-hover dataTable\"
                       data-paging=\"true\" data-page-length=\"10\" data-searching=\"true\"
                       data-ordering=\"true\" data-info=\"true\" data-autowidth=\"true\">
                    <thead>
                    <tr>
                        <th>";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("grase.table.header.username", [], "messages");
        echo "</th>
                        <th>";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Data Usage", [], "messages");
        echo "</th>
                        <th>";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Time Usage", [], "messages");
        echo "</th>
                        <th>";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Expiry", [], "messages");
        echo "</th>
                        <th>";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Last Logout", [], "messages");
        echo "</th>
                        <th>";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Group", [], "messages");
        echo "</th>
                        <th>";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Comment", [], "messages");
        echo "</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 34
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["users"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 35
            echo "                        <tr>
                            <td>";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "username", [], "any", false, false, false, 36), "html", null, true);
            echo "<span class=\"float-right\"><a href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("grase_user_edit", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "username", [], "any", false, false, false, 36)]), "html", null, true);
            echo "\"><i class=\"fas fa-user-edit\"></i></a> <a data-toggle=\"popover\" tabindex=\"0\" data-trigger=\"focus\" title=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("Password", [], "messages");
            echo "\" data-content=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "password", [], "any", false, false, false, 36), "html", null, true);
            echo "\"><i class=\"material-icons md-18 md-dark\">lock</i></a></span></td>
                            <td data-order=\"";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "datausagetotal", [], "any", false, false, false, 37), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->extensions['Twig_Extensions_Extension_Number']->format_bytes(twig_get_attribute($this->env, $this->source, $context["user"], "datausagetotal", [], "any", false, false, false, 37)), "html", null, true);
            echo "/";
            echo twig_escape_filter($this->env, $this->extensions['Twig_Extensions_Extension_Number']->format_bytes(twig_get_attribute($this->env, $this->source, $context["user"], "datalimit", [], "any", false, false, false, 37)), "html", null, true);
            echo "</td>
                            <td data-order=\"";
            // line 38
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "totalSessionTime", [], "any", false, false, false, 38), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "totalSessionTime", [], "any", false, false, false, 38), "html", null, true);
            echo "/";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "timelimit", [], "any", false, false, false, 38), "html", null, true);
            echo "</td>
                            <td data-order=\"";
            // line 39
            ((twig_get_attribute($this->env, $this->source, $context["user"], "expiry", [], "any", false, false, false, 39)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "expiry", [], "any", false, false, false, 39), "U"), "html", null, true))) : (print ("")));
            echo "\">";
            if (twig_get_attribute($this->env, $this->source, $context["user"], "expiry", [], "any", false, false, false, 39)) {
                echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "expiry", [], "any", false, false, false, 39), "medium", "short"), "html", null, true);
            }
            ((twig_get_attribute($this->env, $this->source, $context["user"], "expireAfter", [], "any", false, false, false, 39)) ? (print (twig_escape_filter($this->env, (("(" . twig_get_attribute($this->env, $this->source, $context["user"], "expireAfter", [], "any", false, false, false, 39)) . ")"), "html", null, true))) : (print ("")));
            echo "</td>
                            <td data-order=\"";
            // line 40
            ((twig_get_attribute($this->env, $this->source, $context["user"], "lastLogout", [], "any", false, false, false, 40)) ? (print (twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "lastLogout", [], "any", false, false, false, 40), "U"), "html", null, true))) : (print ("")));
            echo "\">";
            if (twig_get_attribute($this->env, $this->source, $context["user"], "lastLogout", [], "any", false, false, false, 40)) {
                echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "lastLogout", [], "any", false, false, false, 40), "medium", "short"), "html", null, true);
            }
            echo "</td>
                            <td>";
            // line 41
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "allUserGroupsNames", [], "any", false, false, false, 41), "html", null, true);
            echo "</td>
                            <td>";
            // line 42
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "comment", [], "any", false, false, false, 42), "html", null, true);
            echo "</td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "                    </tbody>
                </table>
            </div>

        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "users.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 45,  172 => 42,  168 => 41,  160 => 40,  151 => 39,  143 => 38,  135 => 37,  125 => 36,  122 => 35,  118 => 34,  111 => 30,  107 => 29,  103 => 28,  99 => 27,  95 => 26,  91 => 25,  87 => 24,  76 => 16,  70 => 12,  66 => 11,  61 => 8,  57 => 7,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "users.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/templates/users.html.twig");
    }
}
