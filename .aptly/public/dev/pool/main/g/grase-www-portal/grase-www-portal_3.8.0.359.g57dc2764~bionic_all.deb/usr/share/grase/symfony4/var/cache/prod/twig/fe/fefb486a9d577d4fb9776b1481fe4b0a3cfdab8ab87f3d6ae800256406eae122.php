<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @PdMenu/Default/menuBase.html.twig */
class __TwigTemplate_6ebdd6327b54188b6f3cdfc2b169551b6699f04a2352fce2103d74dcc427770c extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        $this->displayBlock("menu_begin", $context, $blocks);
        echo "
";
    }

    public function getTemplateName()
    {
        return "@PdMenu/Default/menuBase.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  37 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "@PdMenu/Default/menuBase.html.twig", "/builds/grase/grase-www-portal/files/usr/share/grase/symfony4/vendor/appaydin/pd-menu/Resources/views/Default/menuBase.html.twig");
    }
}
